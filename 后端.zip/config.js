module.exports = {
  //加密和解密的密钥属性
  jwtSecretKey : 'itheima No1. ^_^',
  //token有效期为10个小时
  expiresIn:'10h'
}