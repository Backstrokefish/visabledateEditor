const joi = require('joi')

const name = joi.string().required()
const alias = joi.string().alphanum().required()

exports.add_cata_schema = {
  body:{
    name,
    alias,
  },
}