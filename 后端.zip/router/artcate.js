const express = require('express')
const router = express.Router()

const artcate_handle = require('../router_handle/artcate.js')


router.get('/cates',artcate_handle.getArticleCates)

const expressJoi = require('@escook/express-joi')
const {add_cate_schema} = require('../schema/artcate')

router.post('/addcates',expressJoi(add_cate_schema),artcate_handle.addArticleCates)

module.exports = router