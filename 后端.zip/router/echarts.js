const express = require('express')

const router = express.Router()

const echarts_handle = require('../router_handle/echarts.js')

const multipart = require('connect-multiparty');
const multipartyMiddleware = multipart();

router.post('/saveCanvas',multipartyMiddleware,echarts_handle.saveCanvas)

router.post('/saveEchart',echarts_handle.save_currentEchartsList)

router.get('/getCanvas',echarts_handle.getCanves)

router.post('/getEchart',echarts_handle.get_EchartList)

router.post('/delectCanvas',echarts_handle.delect_canvas)

// router.post('/getCanvesImg',echarts_handle.getCanvesImg)

module.exports = router