const express = require('express')

const router = express.Router()

const data_handle = require('../router_handle/data.js')

const multipart = require('connect-multiparty');
const multipartyMiddleware = multipart();


router.get('/getCanvas',echarts_handle.getCanves)

router.post('/getEchart',echarts_handle.get_EchartList)

router.post('/delectCanvas',echarts_handle.delect_canvas)

// router.post('/getCanvesImg',echarts_handle.getCanvesImg)

module.exports = router