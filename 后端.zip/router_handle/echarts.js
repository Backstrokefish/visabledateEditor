
const db = require('../db/echarts.js')

const fs = require("fs");

const multiparty = require("multiparty");

const formidable = require("formidable")

const path =require("path")

let canvasId = 0

exports.saveCanvas = (req,res)=>{
  // console.log('saveCanvas',req.body)
  const req_body_name = req.body.fileName
  const req_body_img = req.body.fileUrl

  var dataBuffer = Buffer.from(req_body_img, 'base64');
  let imgPath = path.join(__dirname,`../public/views/images/${new Date().getTime()}.png`)

  fs.writeFile(imgPath, dataBuffer, function(err,ress) {
    if(err){
      res.cc(err)
    }
  });

  let imgpath ='/'+path.basename(imgPath)
  console.log('imgpath',imgpath)
  const sqlInsertCanvas = 'insert into ev_canvas (name,img) VALUES (?,?)'

  db.query(sqlInsertCanvas,[req_body_name,imgpath],(err,saveCanvasRes)=>{
    console.log('saveCanvasRes',saveCanvasRes)
    if(err){
      res.cc(err)
    }
    canvasId = saveCanvasRes.insertId

    res.cc('保存成功')
  })
}


exports.save_currentEchartsList = (req,res)=>{
  if(req.body.__proto__===undefined)Object.setPrototypeOf(req.body, new Object());

  const req_body_list = req.body.list

  // console.log('req.body',req.body)

  // 定义数据库查询语句
  const sqlStr = 'select * from ev_echart_config where _id = ?'
  req_body_list.forEach((echart)=>{
    console.log('ehcart',echart)
    db.query(sqlStr,echart.id,(err,echartRes)=>{
      if(err) return res.cc(err)
      if(echartRes.length>0) return res.cc()

      const sqlInsert = 'insert into ev_echart_config set ?'
      const sqlInsertOpt = 'insert into ev_echart_config_option set ?'
      
      db.query(sqlInsert,
        {
          type:echart.type,
          x:echart.x,
          y:echart.y,
          width:echart.width,
          height:echart.height,
          canvas_id:canvasId},(err,configRes)=>{
            if(err) return res.cc(err)
            if(configRes.affectedRows !==1) return res.cc('保存失败')
            if(echart.type=='radarChart'){
              console.log('radarChart',echart.option)
              db.query(sqlInsertOpt,{
                backgroundColor:echart.option.backgroundColor,
                titile_text:echart.option.title.text,
                color:JSON.stringify(echart.option.color),
                series:JSON.stringify(echart.option.series),
                radar:JSON.stringify(echart.option.radar),
                tooltip:JSON.stringify(echart.option.tooltip),
                legend:JSON.stringify(echart.option.legend),
                _id:configRes.insertId,
              },(err,results)=>{
                console.log('..',err)
                if(err){
                  console.log('..',err)
                  return res.cc(err)
                }else if(results.affectedRows !==1){
                  console.log('..',results.affectedRows)
                  return res.cc('保存失败')
                }
              })
            }else if(echart.type=='pieChart'){
              db.query(sqlInsertOpt,{
                backgroundColor:echart.option.backgroundColor,
                titile_text:echart.option.title.text,
                color:JSON.stringify(echart.option.color),
                series:JSON.stringify(echart.option.series),
                legend:JSON.stringify(echart.option.legend),
                tooltip:JSON.stringify(echart.option.tooltip),
                _id:configRes.insertId,
              },(err,results)=>{
                if(err){
                  console.log('..err',err)
                  return res.cc(err)
                }else if(results.affectedRows !==1){
                  return res.cc('保存失败')
                }
              })
            }
            else if(echart.type=='lineCharts'||echart.type=='barCharts'){
              db.query(sqlInsertOpt,{
                backgroundColor:echart.option.backgroundColor,
                titile_text:echart.option.title.text,
                color:JSON.stringify(echart.option.color),
                xAxis:JSON.stringify(echart.option.xAxis),
                yAxis:JSON.stringify(echart.option.yAxis),
                series:JSON.stringify(echart.option.series),
                _id:configRes.insertId,
              },(err,results)=>{
                if(err){
                  return res.cc(err)
                }else if(results.affectedRows !==1){
                  return res.cc('保存失败')
                }
              })
            }
            
          })
    })

  })
  res.cc('保存成功')
}

exports.getCanves=(req,res)=>{
  
  const sql = 'select * from ev_canvas' 
  db.query(sql,(err,getCanvasRes)=>{
    console.log('getCanves==err',err)
    if(err) return res.cc(err)
    let obj = {
      data:getCanvasRes
    }
    return res.cc(obj)
  })

  
}

exports.get_EchartList=(req,res)=>{
  console.log('...',req.body)
  const req_canvasId = req.body.id
  

  const sqlGetEchartList = 'select * from ev_echart_config where canvas_id = ?'
  const sqlGetEchartOpt = 'select * from ev_echart_config_option where _id = ?'

  db.query(sqlGetEchartList,req_canvasId,(err,getEchartListRes)=>{
    
    if(err) return res.cc(err)
    if(getEchartListRes.length==0) return res.cc('找不到数据')
    console.log('....getEchartListRes',getEchartListRes)
    getEchartListRes.forEach(el=>{
      db.query(sqlGetEchartOpt,el._id,(err,getEhartOptRes)=>{
        console.log('getEhartOptRes',getEhartOptRes)
        if(err) return res.cc(err)
        if(getEhartOptRes.length==0) {return res.cc('找不到数据')}else{
          
          getEhartOptRes[0].color=JSON.parse(getEhartOptRes[0].color)
          
          getEhartOptRes[0].series=JSON.parse(getEhartOptRes[0].series)
          if(getEhartOptRes[0].xAxis){
            getEhartOptRes[0].xAxis=JSON.parse(getEhartOptRes[0].xAxis)
          }
          if(getEhartOptRes[0].yAxis){
            getEhartOptRes[0].yAxis=JSON.parse(getEhartOptRes[0].yAxis)
          }
          if(getEhartOptRes[0].tooltip){
            getEhartOptRes[0].tooltip=JSON.parse(getEhartOptRes[0].tooltip)
          }
          if(getEhartOptRes[0].legend){
            getEhartOptRes[0].legend=JSON.parse(getEhartOptRes[0].legend)
          }
          if(getEhartOptRes[0].radar){
            getEhartOptRes[0].radar=JSON.parse(getEhartOptRes[0].radar)
          }
          console.log('getEhartOptRes[0].legend',getEhartOptRes[0])
          el.option = getEhartOptRes[0]
        }
       
      })
    })
    setTimeout(() => {
      let obj = {
        data:getEchartListRes
      }
      res.cc(obj)
    }, 500);

  })
  
}

exports.delect_canvas = (req,res)=>{
  const canvasId = req.body.id

  const sqlDelectStr = 'delete parent,child,childchild from ev_canvas parent,ev_echart_config child,ev_echart_config_option childchild where parent._id=child.canvas_id and child._id = childchild._id and parent._id = ?'

  db.query(sqlDelectStr,canvasId,(err,delectRes)=>{
    if(err) return res.cc(err)

    // console.log('delectRes',delectRes)

    res.cc('删除成功',0)
  })
}