-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: my_db_visabledata
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ev_echart_config_option`
--

DROP TABLE IF EXISTS `ev_echart_config_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `ev_echart_config_option` (
  `option_id` int(255) NOT NULL AUTO_INCREMENT,
  `backgroundColor` varchar(255) DEFAULT NULL,
  `titile_text` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `xAxis` varchar(255) DEFAULT NULL,
  `yAxis` varchar(255) DEFAULT NULL,
  `series` text,
  `_id` int(255) NOT NULL,
  `radar` varchar(255) DEFAULT NULL,
  `tooltip` varchar(255) DEFAULT NULL,
  `legend` varchar(255) DEFAULT NULL,
  `toolbox` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`option_id`),
  KEY `_id_idx` (`backgroundColor`),
  KEY `_id_idx1` (`_id`),
  CONSTRAINT `_id` FOREIGN KEY (`_id`) REFERENCES `ev_echart_config` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ev_echart_config_option`
--

LOCK TABLES `ev_echart_config_option` WRITE;
/*!40000 ALTER TABLE `ev_echart_config_option` DISABLE KEYS */;
INSERT INTO `ev_echart_config_option` VALUES (8,'rgba(255, 255, 255, 0)','柱状图','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]','{\"type\":\"category\",\"data\":[\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\",\"Sun\"]}','{\"type\":\"value\"}','[{\"data\":[120,200,150,80,70,110,130],\"type\":\"bar\"}]',8,NULL,NULL,NULL,NULL),(9,'rgba(255, 255, 255, 0)','折线图','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]','{\"type\":\"category\",\"data\":[\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]}','{\"type\":\"value\"}','[{\"data\":[150,230,224,218,135,147,260],\"type\":\"line\"},{\"data\":[90,80,100,30,20,50,60],\"type\":\"line\"}]',9,NULL,NULL,NULL,NULL),(10,'rgba(255, 255, 255, 0)','折线图','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]','{\"type\":\"category\",\"data\":[\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]}','{\"type\":\"value\"}','[{\"data\":[150,230,224,218,135,147,260],\"type\":\"line\"},{\"data\":[90,80,100,30,20,50,60],\"type\":\"line\"}]',10,NULL,NULL,NULL,NULL),(26,'rgba(255, 255, 255, 0)','Basic Radar Chart','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]',NULL,NULL,'[{\"name\":\"Budget vs spending\",\"type\":\"radar\",\"data\":[{\"value\":[4200,3000,20000,35000,50000,18000],\"name\":\"Allocated Budget\"},{\"value\":[5000,14000,28000,26000,42000,21000],\"name\":\"Actual Spending\"}]}]',36,'{\"indicator\":[{\"name\":\"Sales\",\"max\":6500},{\"name\":\"Administration\",\"max\":16000},{\"name\":\"Information Technology\",\"max\":30000},{\"name\":\"Customer Support\",\"max\":38000},{\"name\":\"Development\",\"max\":52000},{\"name\":\"Marketing\",\"max\":25000}]}','{\"trigger\":\"item\"}','{\"data\":[\"Allocated Budget\",\"Actual Spending\"]}',NULL),(27,'rgba(255, 255, 255, 0)','饼状图','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]',NULL,NULL,'[{\"name\":\"Access From\",\"type\":\"pie\",\"radius\":[\"40%\",\"70%\"],\"avoidLabelOverlap\":false,\"label\":{\"show\":false,\"position\":\"center\"},\"emphasis\":{\"label\":{\"show\":true,\"fontSize\":\"40\",\"fontWeight\":\"bold\"}},\"labelLine\":{\"show\":false},\"data\":[{\"value\":1048,\"name\":\"Search Engine\"},{\"value\":735,\"name\":\"Direct\"},{\"value\":580,\"name\":\"Email\"},{\"value\":484,\"name\":\"Union Ads\"},{\"value\":300,\"name\":\"Video Ads\"}]}]',37,NULL,'{\"trigger\":\"item\"}','{\"top\":\"5%\",\"left\":\"center\"}',NULL),(34,'rgba(255, 255, 255, 0)','饼状图','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]',NULL,NULL,'[{\"name\":\"Access From\",\"type\":\"pie\",\"radius\":[\"40%\",\"70%\"],\"avoidLabelOverlap\":false,\"label\":{\"show\":false,\"position\":\"center\"},\"emphasis\":{\"label\":{\"show\":true,\"fontSize\":\"40\",\"fontWeight\":\"bold\"}},\"labelLine\":{\"show\":false},\"data\":[{\"value\":1048,\"name\":\"Search Engine\"},{\"value\":735,\"name\":\"Direct\"},{\"value\":580,\"name\":\"Email\"},{\"value\":484,\"name\":\"Union Ads\"},{\"value\":300,\"name\":\"Video Ads\"}]}]',44,NULL,'{\"trigger\":\"item\"}','{\"top\":\"5%\",\"left\":\"center\"}',NULL),(35,'rgba(255, 255, 255, 0)','Basic Radar Chart','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]',NULL,NULL,'[{\"name\":\"Budget vs spending\",\"type\":\"radar\",\"data\":[{\"value\":[4200,3000,20000,35000,50000,18000],\"name\":\"Allocated Budget\"},{\"value\":[5000,14000,28000,26000,42000,21000],\"name\":\"Actual Spending\"}]}]',45,'{\"indicator\":[{\"name\":\"Sales\",\"max\":6500},{\"name\":\"Administration\",\"max\":16000},{\"name\":\"Information Technology\",\"max\":30000},{\"name\":\"Customer Support\",\"max\":38000},{\"name\":\"Development\",\"max\":52000},{\"name\":\"Marketing\",\"max\":25000}]}','{\"trigger\":\"item\"}','{\"data\":[\"Allocated Budget\",\"Actual Spending\"]}',NULL),(36,'rgba(255, 255, 255, 0)','折线图','[\"#5470c6\",\"#91cc75\",\"#fac858\",\"#ee6666\",\"#73c0de\",\"#3ba272\",\"#fc8452\",\"#9a60b4\",\"#ea7ccc\"]','{\"type\":\"category\",\"data\":[\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]}','{\"type\":\"value\"}','[{\"data\":[150,230,224,218,135,147,260],\"type\":\"line\"},{\"data\":[90,80,100,30,20,50,60],\"type\":\"line\"}]',46,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ev_echart_config_option` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-28 15:31:04
