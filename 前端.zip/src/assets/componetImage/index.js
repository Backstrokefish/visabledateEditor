const images = {
  lineCharts: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/line-simple.png?_v_=1652838344997',
  barChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/bar-background.png?_v_=1652838344997',
  pieChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/pie-doughnut.webp?_v_=1612615474746',
  radarChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/radar.webp?_v_=1612615474746',
  scatterChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/scatter-simple.png?_v_=1639201079239',
  treeChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/tree-basic.png?_v_=1639201079239',
  gaugeChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/gauge-simple.webp?_v_=1612615474746',
  graphChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/graph-simple.webp?_v_=1612615474746',
  funnelChart: 'https://fastly.jsdelivr.net/gh/apache/echarts-website@asf-site/examples/data/thumb/funnel.webp?_v_=1612615474746'
};

export default images;
