export const option = {
  color:['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de', '#3ba272', '#fc8452', '#9a60b4', '#ea7ccc'],
  backgroundColor:"rgba(255, 255, 255, 0)",
  title: {
    text: 'Tree'
  },
  tooltip: {
    trigger: 'item',
    triggerOn: 'mousemove'
  },
  series: [
    {
      type: 'tree',
      data: [{
        name:'Parent',
        children:[{
          name:"chile_1",
          children:[{
            name:"child_1_1",
          },
          {
            name:"child_1_2",
           
          }],
          collapsed:true
        },
        {
          name:"chile_2",
          children:[{
            name:"child_2_1",
  
          },
          {
            name:"child_2_2",
           
          }],
          collapsed:true
        },
        {
          name:"chile_3",
          children:[{
            name:"child_3_1",
          },
          {
            name:"child_3_2",
           
          }],
          collapsed:true
        }]
      }],
      top: '1%',
      left: '7%',
      bottom: '1%',
      right: '20%',
      symbolSize: 7,
      label: {
        position: 'left',
        verticalAlign: 'middle',
        align: 'right',
        fontSize: 9
      },
      leaves: {
        label: {
          position: 'right',
          verticalAlign: 'middle',
          align: 'left'
        }
      },
      emphasis: {
        focus: 'descendant'
      },
      expandAndCollapse: true,
      animationDuration: 550,
      animationDurationUpdate: 750
    }
  ]
}