export const  option = {
  color:['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de', '#3ba272', '#fc8452', '#9a60b4', '#ea7ccc'],
  backgroundColor:"rgba(255, 255, 255, 0)",
  title:{
    text:'scatter'
  },
  xAxis: {},
  yAxis: {},
  series: [
    {
      symbolSize: 20,
      data: [
        [1.0, 8.04],
        [3.07, 6.95],
        [12.0, 7.58],
        [5.05, 8.81],
        [6.0, 8.33],
        [10.0, 7.66],
        [13.4, 6.81],
      ],
      type: 'scatter'
    }
  ]
};