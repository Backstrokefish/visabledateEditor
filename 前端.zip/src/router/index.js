import Vue from "vue"
import VueRouter from "vue-router"

Vue.use(VueRouter);

import pieChart from '../components/editEchartsComponet/pieChart.vue'
import mainVue from '../components/main.vue'
import personal from '../components/PersonalCenter/index.vue'
import kanban from '../components/kanban/index.vue'

const router = new VueRouter({
  routes:[
    {
      path:'/',
      redirect:'/mainVue'
    },
    {
      path: '/pieChart',
      component: pieChart
    },
    {
      path: '/mainVue',
      component: mainVue
    },
    {
      path: '/personal',
      component: personal
    },
    {
      path: '/kanban',
      component: kanban
    },
  ]

})

export default router;