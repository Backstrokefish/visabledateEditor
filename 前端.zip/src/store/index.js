import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    echartsListCompt:'',//组件分类，‘柱状图，折线图’
    CurrentEchart:{},//当前组件
    curEdit: {}, // 当前编辑的图表
    currentChartList: [], // 当前文件的当前数据
    dataVisualization: {
      dataEcharts: {
        barChart : [], // 柱状图数组
        barChartIndex : 0, // 当前柱状图索引
        lineCharts : [], // 折线图数组
        lineChartsIndex : 0, // 当前柱状图索引
        pieChart : [], // 饼状图数组
        pieChartIndex : 0, // 饼状图索引
        radarChart :[],//雷达图数组
        radarChartIndex :0,//雷达图索引
        gaugeChart:[],//仪表盘数组
        gaugeChartIndex:0,//仪表盘索引
        funnelChart:[],//倒三角数组
        funnelChartIndex:0,//倒三角索引
        scatterChart :[],//散点图
        scatterChartIndex:0,
        treeChart:[],//树状图
        treeChartIndex:0,//树状图索引
      },
      dataBase: { // 后期补充基础元素的拖拽

      }
    }
  },
  getters: {
    getDataEchartsItem: (state) => ({type= 'barChart',id = null } = {}) => {
      if(id === null) return {};
      return state.dataVisualization.dataEcharts[type].find(item => item.id === id);
    },
    getDataEchartsIndex: (state) =>({type= 'barChart'} = {}) => {
      console.log("store==>getDataEchartsIndex")
      return state.dataVisualization.dataEcharts[type+'Index'];
    },
  },
  mutations: {
      // 设置当前编辑的图表
      setCurEdit (state, data) {
        console.log('Store=>setCurEdit=>curEdit')
        state.curEdit = data
        console.log(state.curEdit)
      },
  
      // 当前画布添加图表
      addChart (state, data) {
        state.currentChartList.push(data)
        console.log('Store=>addChart=>currentChartList',state.currentChartList)
      },
    addDataEchartsItem(state,{type = 'barChart',option = 'option'} = {}){
      state.dataVisualization.dataEcharts[type].push(option);
    },
    addDateEchartsOffset(state,{type = 'barChart',offsetConfig='offsetConfig'} = {}){
      state.dataVisualization.dataEcharts[type].push(offsetConfig);
    },
    addDataEchartsIndex(state,{type = 'barChart'} = {}){
      state.dataVisualization.dataEcharts[type+'Index'] += 1;
     console.log('Store=>====>ChartIndex',state.dataVisualization.dataEcharts[type+'Index'])

    },
    setCurrentEchart(state,CurrentEchart){
      state.CurrentEchart=CurrentEchart
    },
    setEchartsListCompt(state,type){
      state.echartsListCompt=type
    },
   
  },
  actions: {},
  modules: {}
});
