<template>
  <div class="Container">
    <div class="ctlBtn">
      <el-button @click="handleFullScreen" icon="el-icon-full-screen" size="small"></el-button>
      <el-button @click="goPersonal" icon="el-icon-user" size="small"></el-button>
      <el-button @click="saveDialogVisible" icon="el-icon-s-order" size="small"></el-button>
    </div>

    <div id="LeftOfliebiao" class="LeftOfliebiao">
      <div id="componetList" class="componetList">
        <left-componet-list-bar  @addChart="addChart"></left-componet-list-bar>
      </div>
    </div>
    <div id="MainChartjihe" class="MainChartjihe">
      <canve-contain ref="canva" @transfer="closeSavaDialog" :isFullSize="isFullSize" :addChartType="addChartType" :IsCanvasPrepared='IsCanvasPrepared' ></canve-contain>
    </div>
    
    <!-- 保存对话框 -->
    <el-dialog
      title="保存"
      :visible.sync="dialogVisible"
      width="20%"
      center
      >
      <el-form :model="form">
        <el-form-item label="画布名称" :label-width="formLabelWidth">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="savaCanvas">确 定</el-button>
      </span>
    </el-dialog>
  </div>

</template>

<script>

import LeftComponetListBar from './LeftComponeList/LeftComponetListBar.vue'
import canveContain from './MainChartjihe/canveContain.vue'

import {mapState} from 'vuex'

// import RightEditorComponet from './RightEditorComponet/index.vue'
export default {
  data(){
    return {
      isFullSize: false,
      offsetConfig:{},
      addChartType:{},
      IsCanvasPrepared:false,
      dialogVisible:false,
      formLabelWidth: '0.5rem',
      form:{
        name:''
      },
      filename:'',
      file_url:'',
      showEidt:false
    }
  },
  computed: {
  ...mapState({
      currentChartList: state => state.currentChartList,
    }),
  },
  methods:{
    saveDialogVisible(){
      this.dialogVisible=true
    },

    savaCanvas(){
      this.$refs.canva.saveImage(this.form.name)
    },
    closeSavaDialog(val){
      this.dialogVisible=val
      this.form.name=''
    },
    goPersonal(){
      this.$router.push("/personal");
      // this.showEidt=false
      
    },
     handleFullScreen () {
      this.isFullSize = !this.isFullSize
    },
     addChart (type) {
      console.log('Mainvue=>addChart=>type',type)
      this.IsCanvasPrepared=!this.IsCanvasPrepared
      this.addChartType = {type:type,IsIsCanvasPrepared:this.IsCanvasPrepared}
    },
    
  },
  components:{
    LeftComponetListBar,
    canveContain,
    // RightEditorComponet,
  }
}
</script>

<style lang='less' scoped>
  @media screen and (max: width 1024px) {
    html {
      font-size: 42.66px !important;
    }
    
  }

  @media screen and (min: width 1920px) {
    html {
      font-size: 80px !important;
    }
    
  }
*{
  margin: 0;
  padding: 0;
}

.Container{
  display: flex;
  width: 100%;
  height: 5rem;
}

.ctlBtn{
  display: flex;
  border: .01rem solid rgb(220, 234, 243);
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;

  /deep/.el-button+.el-button {
   margin-left: 0px; 
   margin-top: 5px;
}
}

.LeftOfliebiao{
  flex: 1.5;
  border: .01rem solid rgb(235, 206, 206);
}
.componetList{
  width: 100%;
  height:100%;
}

.MainChartjihe{
  flex: 8;
  border: .01rem solid rgb(235, 206, 206);
}

// .RightEdit{
//   flex: 2;
//   border: .01rem solid rgb(235, 206, 206);
// }


</style>