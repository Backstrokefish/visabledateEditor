<template>
  <div class="container">
    <!-- <div class="seletConfig" id="seletConfig">
      <el-button icon="el-icon-user" @click="goPersonal"></el-button>
    </div> -->
    <div class="component-support-list" id="ListComponet"  >
      <!-- <draggable  @dragstart.native="dragStart($event,'histogram')"> -->
      <el-card shadow="hover" class="component-support-item"  v-for="(item,index) in selectType"  :index="item.name" :key="index"  
      @dragstart.native="dragStart(item.code)" >
        <img :src="componentImage[item.code]" alt="componetList">
      </el-card>
      <!-- </draggable> -->
      
    </div>
  </div>
</template>

<script>
// import draggable from "vuedraggable";
import images from '@assets/componetImage/index'
import presetComponents from '@assets/componts/presetComponents.js'
import {mapMutations,mapState } from 'vuex'
import {saveChartsList} from '@api/echarts.js'
export default {
    data(){
      return{
        componentImage:images,
        selectType:presetComponents.charts.children,
      }
    },
    components:{
      // draggable
    },
     computed: {
    ...mapState({
       currentChartList: state => state.currentChartList,
     }),
     },
    methods:{
       ...mapMutations(['setEchartsListCompt']),
      
      dragStart(type){
        // event.dataTransfer.Text=type;
       console.log('LeftComponetBar.VUE==>dragStart==>type',type)
       this.setEchartsListCompt(type)
       this.$emit('addChart', type)
      },
      goPersonal(){
        console.log("this.currentChartList.length",this.currentChartList)
        let currentChartConfig = {
          height:this.currentChartList[0].height,
          id:this.currentChartList[0].id,
          type:this.currentChartList[0].type,
          width:this.currentChartList[0].width,
          x:this.currentChartList[0].x,
          y:this.currentChartList[0].y,
          option:this.currentChartList[0].option
        }
        console.log('currentChartConfig',currentChartConfig)
        if(this.currentChartList.length==0){
          this.$router.push("/personal");
        }else {
          //console.log(saveChartsList())
          saveChartsList(currentChartConfig).then((res)=>{
            console.log(res.data)
          })
         
        }
        
      }
    },
    mounted(){
      
    }
}
</script>

<style lang="less" scoped>
.container{
  margin: 0;
  padding: 0;
  display: flex;
}
  .seletConfig{
    flex:2
  }

  /deep/.el-card__body {
    padding: 10px;
}

  .component-support-list {
    flex: 8;
    height:5rem;
    overflow: scroll;
    background: #ffffff;
    .component-support-item{
      box-sizing: border-box;
      padding: .03rem;
      margin-bottom: .04rem;
      background: #f7f7fc;
      // filter: invert(8);
      img{
        width: 100%;
        height: .5rem;
      }
    }
  }
</style>