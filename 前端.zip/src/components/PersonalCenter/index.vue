<template>
  <div>
    <header>
      <div class="header_div">
        <span><i class="el-icon-user-solid"></i>个人中心</span>
        <span class="home_Page" @click="goback">首页</span>
      </div>
    </header>
    <div class="main_Content">
      <div class="left_Message"></div>
      <div class="vue_Card">
        <div class="card_content">
          <div v-for="(item, index) in cavansList" :key="item._id+index">
            <el-card class="box-card" shadow="hover" @click.native="getCanvaId(item._id)" @mouseenter.native="showdelect(index)" @mouseleave.native="hidendelect()">
               <el-image
                  :src="getImgSrc(item.img)"
                  >
                  </el-image>
               <p style="font-size:14px;margin-top: 4px;">{{item.name}}</p>
               <div class="delect_btn"><el-button icon='el-icon-delete' v-show='echartIndex==index? true:false' @click.stop="delectCanvaMet(item._id)"></el-button></div>
            </el-card>
           
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import {mapState,mapMutations} from "vuex"
import {getCanvas,delectCanvas} from '@api/echarts.js'
import bus from '../../utils/bus'
export default {
  data(){
    return{
      path:'http://127.0.0.1:3007',
      cavansList:{},
      delectIcon:false,
      echartIndex:0,
    }
  },
  computed: {
    ...mapState({
       currentChartList: state => state.currentChartList,
     }),
  },
  created(){
    console.log("currentChartList",this.currentChartList)
    this.getCanvasMet()
  },
  methods:{
    ...mapMutations(['setCurrentEchart']),
  
    delectCanvaMet(id){
      console.log('id',id)
      let obj = {
        id:id
      }
      delectCanvas(obj).then((res)=>{
        console.log('Delectres',res)
        if(res.data.status==0){
          console.log('jjinlaile ?')
          this.$message({
            type: 'success',
            message: res.data.message
          });
          this.getCanvasMet()
        }
      })
    },
    showdelect(index){
      this.echartIndex = index
    },
    hidendelect(){
      this.echartIndex=-1
    },
    getCanvaId(id){
      console.log('id',id)
      bus.$emit('getEchartsListMet',id)
      this.$router.push("/kanban")
    },
    getImgSrc(imgPath){
      return this.path+imgPath
    },
    goback(){
      this.$router.push("/")
      let showEidtbool = true
      bus.$emit('setEchartsListMet',showEidtbool)
    },
    getCanvasMet(){
      getCanvas().then((res)=>{
        console.log(res)
        this.cavansList = res.data.data
        console.log(this.cavansList)
      })
    }
  },

}
</script>

<style scoped lang='less'>
body{
  margin: 0;
  padding: 0;
  .header_div{
    display: flex;
    margin-bottom: .06rem;
    color: rgb(49, 48, 48);
    .home_Page{

      margin-left:10px;
    }
    .home_Page:hover{
      cursor:pointer;
      color: rgb(102, 160, 214);
    } 
  }
  .main_Content{
    display: flex;
    width: 98%;
    height: 4.5rem;
    border: 1px salmon solid;
    .left_Message{
      flex: 1;
      width: 100%;
      height: 100%;
      border: 1px steelblue solid;
    }
    .vue_Card{
      flex: 9;
      width: 100%;
      height: 100%;
      border: 1px rgb(70, 164, 180) solid;
      .card_content{
        display: flex;
        flex-wrap: wrap;
        align-content: center;
        justify-content: flex-start;
        align-items: center;
        .box-card{
          margin-left: .15rem;
          margin-top:.13rem;
          width: 1.2rem;
          height: 1.2rem;
          border: 1px #e1dbe2 solid;
          .delect_btn{
            height: 23px;
            width: 100%;
            // border: red 1px solid;
            margin-top: -10px;
            /deep/.el-button{
            width: 100%;
            height: 100%;
            padding: 4px 20px;
            //  padding-top: .19rem;
          }
          }
         
        }
      }

    }
  }
}

</style>