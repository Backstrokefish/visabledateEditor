<template>
    <div>
        <div id="pieChart" class="pChart"></div>
    </div>
</template>

<script>
export default {
    name:"pieChart",
   
    props:{
        items:{
            type:Array,
            default(){
                return [
                        {value: 1048, name: '搜索引擎'},
                        {value: 735, name: '直接访问'},
                        {value: 580, name: '邮件营销'},
                        {value: 484, name: '联盟广告'},
                        {value: 300, name: '视频广告'}
                    ]
            }
        },
    },

    mounted() {
                           
    const  option = {
            color:["#8696a7",
            "#afb0b2",
            "#c1cbd7",],
            title: {
                left: 'center'
            },
            tooltip: {
                trigger: 'item'
            },
            legend: {
                orient: 'vertical',
                left: 'left',
            },
            series: [
                {
                    name: '访问人数',
                    type: 'pie',
                    radius: '50%',
                    data: [],
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };
        this.items.forEach(el => {
        option.series[0].data.push({
            value:el.value,
            name:el.name,
        });
      })                       

      //初始化
      const chartObj = this.$echarts.init(document.getElementById('pieChart'))
      chartObj.setOption(option)
  },
}
</script>
<style>
  
  .pChart{
      width: 500px;
      height: 500px;
  }

</style>