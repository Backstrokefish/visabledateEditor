<template>
 <div>
    <div class="edit_char_config">
      <div class="title_chart">
        <span class="title_text" >标题 ：</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.option.title.text" @change="changeTitle(dblclickObj.id)"></el-input>
      </div>
     <div class="coordinate">
        <div class="A_bscissa">
        <span class="title_text" >位移 X :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.x"></el-input>
      </div>
      <div class="O_rdinate">
        <span class="title_text" >位移 Y :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.y"></el-input>
      </div>
     </div>
      <div class="coordinate">
        <div class="A_bscissa">
        <span class="title_text" >宽 :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.w"></el-input>
      </div>
      <div class="O_rdinate">
        <span class="title_text" >高 :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.h"></el-input>
      </div>
     </div>

      <!-- 数据 -->
      <el-collapse >
      <el-collapse-item >
         <template slot="title">
          <span class="axiso_title">数据 :</span><i class="el-icon-caret-right"></i></template>
        <div v-for="(series,index) in dblclickObj.option.series[0].data" :key="index">
         <div class="delect_axisoy" @mouseenter="showDelectIconMet(index)" @mouseleave="closeDelectIco">
            <div class="delect_input">
              <el-input v-model="modifiteDataArr[index].name" :placeholder="series.name" @change="changeInputDate(index)"></el-input>
              <el-input v-model="modifiteDataArr[index].value" :placeholder="series.value+''" @change="changeInputDate(index)"></el-input>
            </div>
            <!-- 删除 -->
            <div class="delect_icon" v-show="showDelectIcon&&n==index" >
              <el-button size="small" type="danger" icon="el-icon-delete" circle @click="delectInputDate(index)"></el-button>
            </div>
         </div>
        </div>
        <!-- 添加 -->
        <div class="add_yaxiso" @click="addInputItemDate()"><i class="el-icon-circle-plus-outline"></i></div>
      </el-collapse-item>
    </el-collapse>
    </div>
 </div>
</template>

<script>
import { mapState, } from 'vuex'
 export default {
   components: {

   },
   props: {
     dblclickObj: {
       type: Object,
       default: null,
     },
     showEdit:{
       default:false
     },

   },
   data () {
     return {
       editCurrentChartobj:{},
      //  图表题目
       titleText:'',
      //  x轴变量对象，数组
       modifiteData:'',
       modifiteDataArr:[],
      //  y轴变量数组
       modifiteItemIndicator:[],
       modifiteItemArrY:[],

       //组件类型
       chartType:'',
       //判断显示产出icon的显示
       showDelectIcon:false,
       n:0,
     }
   },
   watch:{
     dblclickObj:{
       handler(newVal){
        console.log('test.vue==>handler')
        this.modifiteDataArr=[]
        this.dblclickObj=newVal
        console.log('this.dblclickObj',this.dblclickObj)
        newVal.option.series[0].data.forEach((element =>{
            let obj ={
              value:element.value+'',
              name:element.name
            }
           this.modifiteDataArr.push(obj)
           console.log("????????????0000")
         }))
         console.log('=====test.vue==>this.dblclickObj==>',this.dblclickObj)
         console.log('=====test.vue==>this.==>currentList',this.currentChartList)
       },
       deep:true,
       immediate: true
     }
   },
   created () {
     console.log('this.dblcl',this.dblclickObj)
    //  console.log('test.vue==>this.currentChartList==>',this.currentChartList)
   },
   mounted () {
   },
    computed: {
    ...mapState({
       currentChartList: state => state.currentChartList,
     }),
  },
   methods: { 
    //  编辑标题
     changeTitle(id){
       this.$emit("renderEcharts",id)
     },
    //  显示删除icon
     closeDelectIco(){
       this.showDelectIcon=false
     },
     showDelectIconMet(index){
       this.n=index
       this.showDelectIcon=true
     },

    // data输入框发生变化
     changeInputDate(index){
       console.log("test=666666=>changeInputDate",this.modifiteDataArr)
       console.log("77777",index)
       this.currentChartList.forEach(element => {
         if(this.dblclickObj.id==element.id){
           console.log("......,",this.dblclickObj.id)
           let arr=this.modifiteDataArr[index].value.split(',')
           this.dblclickObj.option.series[0].data[index].value=arr
           this.dblclickObj.option.series[0].data[index].name=this.modifiteDataArr[index].name
           console.log("888888888",this.modifiteDataArr)
           console.log("888888888",element.option.series)
           this.$emit("renderEcharts",this.dblclickObj.id)
         }
       });
     },
      //  删除数据
     delectInputDate(index){
       console.log('test.vue==>delectInputDate')
       console.log('test.vue==>',index)
       this.dblclickObj.option.series[0].data.splice(index,1)
       console.log('test.vue==>this.dblclickObj.option.series',this.dblclickObj.option.series)
       this.$emit("renderEcharts",this.dblclickObj.id)
     },
    //  添加data
     addInputItemDate(){
      console.log("test==addInputItemY")
       let item = {
         value:'',
         name:'name'
       }
       this.dblclickObj.option.series[0].data.push(item)
       this.modifiteDataArr.push(item)
       console.log("test==this.dblclickObj.option.series[0].data",this.dblclickObj.option.series[0].data)
       console.log("test==this.modifiteDataArr.push(item)",this.modifiteDataArr)      
     },
   },
 }
</script>

<style scoped lang='less'>
  .edit_char_config{
    background: #f7f7fc;
     .title_chart{
      display: flex;
      height: .19rem;
      .title_text{
        width:.38rem;
        text-align:center;
        padding-top: .04rem;
        display:block;
      }
    }
    .coordinate{
      display: flex;
      border: 0.01rem solid #cbeded;
      .A_bscissa{
        display: flex;
        height: .19rem;
         .title_text{
        width:.38rem;
        text-align:center;
        padding-top: .04rem;
        display:block;
        }
        /deep/.el-input {
            width: .38rem;
            margin: auto;
        }
      }
      .O_rdinate{
        display: flex;
        height: .19rem;
        .title_text{
        width:.38rem;
        text-align:center;
        padding-top: .04rem;
        display:block;
        }
        /deep/.el-input {
            width: .38rem;
            margin: auto;
        }
      }

    }
    .axiso_title{
      font-size: 14px;
      padding-left: .13rem;
    }
    .add_yaxiso{
      height: 1px;
      width: 100%;
    }
     .add_yaxiso :hover{
      height: 18px;
      width: 100%;
      background-color: #f7f7fc;
    }
    .delect_axisoy{
      display: flex;
      .delect_input{
        flex: 9;

      }
      .delect_icon{
        flex: 1;
        height: 50%;
        margin: auto;
      }
    }

    /deep/.el-collapse-item__header {
    background-color: #f7f7fc;
    }
  }
 

 
</style>
