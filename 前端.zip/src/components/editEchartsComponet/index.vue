<template>
  <div ref="chart" style="height:100%;width:100%"></div>
</template>

<script>
// import echarts from 'echarts'


export default {
  name: 'chart',
  props: {
    theme: {
      type: String,
      default: ''
    },
    height: {
      type: Number,
      default: 0
    },
    width: {
      type: Number,
      default: 0
    },
    option: {
      type: Object,
      default: () => { }
    }
  },
  watch: {
    option: {
      handler (newVal) {
        this.myChart.dispose()
        this.myChart=this.$echarts.init(this.$refs.chart,newVal);
        // this.myChart = echarts.init(this.$refs.chart, newVal)
        this.myChart.setOption(this.option)
      },
      deep: true
    },
    theme (newVal, oldVal) {
      if (newVal !== oldVal) {
        this.myChart.dispose()
        // this.myChart = echarts.init(this.$refs.chart, newVal)
        this.myChart=this.$echarts.init(this.$refs.chart,newVal);
        this.myChart.setOption(this.option)
      }
    },
    height (newVal, oldVal) {
      if (newVal !== oldVal) {
        this.onResize()
      }
    },
    width (newVal, oldVal) {
      if (newVal !== oldVal) {
        this.onResize()
      }
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.drawChart()
    })
  },
  methods: {
    drawChart () {
      // this.myChart = echarts.init(this.$refs.chart, this.theme)
      this.myChart=this.$echarts.init(this.$refs.chart,this.theme);
      
      this.myChart.setOption(this.option)
    },
    onResize () {
      this.myChart && this.myChart.resize()
    }
  }
}
</script>

<style scoped lang="less">
</style>
