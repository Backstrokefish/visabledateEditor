<template>
  <div class="block">
    <el-collapse >
     <el-collapse-item >
      <template slot="title">
      <span class="axiso_title">backgroundcolor :</span><i class="el-icon-caret-right"></i></template>
      <div class="color_item">
        <el-input class="color_input" v-model="backgroundColor" ></el-input>
        <div class="color_picker">
          <el-color-picker v-model="backgroundColor"
          show-alpha
          :predefine="predefineColors"></el-color-picker>
        </div>
      </div>
     </el-collapse-item >
    </el-collapse>
  </div>
</template>

<script>
import { mapState, } from 'vuex'
export default {
  data(){
    return {
      backgroundColor:'rgba(255, 69, 0, 0.68)',
      predefineColors: [
        '#ff4500',
        '#ff8c00',
        '#ffd700',
        '#90ee90',
        '#00ced1',
        '#1e90ff',
        '#c71585',
        'rgba(255, 69, 0, 0.68)',
        'rgb(255, 120, 0)',
        'hsv(51, 100, 98)',
        'hsva(120, 40, 94, 0.5)',
        'hsl(181, 100%, 37%)',
        'hsla(209, 100%, 56%, 0.73)',
        '#c7158577'
      ]
    }
  },
  props: {
     dblclickObj: {
       type: Object,
       default: null,
     },
   },
   watch:{
     dblclickObj:{
       handler(newVal){
        console.log('color.vue==>handler',newVal)
        //  this.colorArr=[]
         this.dblclickObj=newVal
        //  this.colorString=''
         console.log('=====color.vue==>this.dblclickObj==>',this.dblclickObj)
         console.log('=====color.vue==>this.==>currentList',this.currentChartList)
         this.backgroundColor=newVal.option.backgroundColor
       },
       deep:true,
        immediate: true
     },
     backgroundColor(newVal,oldVal){
       console.log('color==>newVal,oldVal',newVal,oldVal)
       this.backgroundColor=newVal
       this.dblclickObj.option.backgroundColor=newVal
       this.$emit("renderEcharts",this.dblclickObj.id)
     },
   },
   created () {
     console.log('this.dblcl',this.dblclickObj)
   },
   computed: {
    ...mapState({
       currentChartList: state => state.currentChartList,
     }),
  },

}
</script>
<style lang="less" scoped>
  .block{
    margin: 0;
    padding: 0;
    border: solid 1px #f7f7fc;
    .axiso_title {
        font-size: 14px;
        padding-left: 0.13rem;
    }
    .demonstration{
      width: 100%;
      height: 100%;
      text-align: center;
    }
    .color_item{
      display: flex;
      .color_input{
        flex: 8;
      }
      .color_picker{
        flex: 2;
      }

    }
  }
   /deep/.el-collapse-item__header {
    background-color: #f7f7fc;
    }
    /deep/.el-collapse-item__content {
    
    padding-bottom: 0;
    margin: auto;
}

</style>