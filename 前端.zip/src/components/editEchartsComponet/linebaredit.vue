<template>
 <div>
    <div class="edit_char_config">
      <div class="title_chart">
        <span class="title_text" >标题 ：</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.option.title.text" @change="changeTitle(dblclickObj.id)"></el-input>
      </div>
     <div class="coordinate">
        <div class="A_bscissa">
        <span class="title_text" >位移 X :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.x"></el-input>
      </div>
      <div class="O_rdinate">
        <span class="title_text" >位移 Y :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.y"></el-input>
      </div>
     </div>
      <div class="coordinate">
        <div class="A_bscissa">
        <span class="title_text" >宽 :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.w"></el-input>
      </div>
      <div class="O_rdinate">
        <span class="title_text" >高 :</span>
        <el-input size="small" placeholder="" v-model="dblclickObj.h"></el-input>
      </div>
     </div>
     <!-- x轴数值设置 -->
     <el-collapse >
      <el-collapse-item >
        <template slot="title">
          <span class="axiso_title">x轴</span><i class="el-icon-caret-right"></i></template>
        <div>
          <el-input v-model="modifiteItemX" :placeholder="dblclickObj.option.xAxis.data" @change="changeInputX()"></el-input>
        </div>
      </el-collapse-item>
    </el-collapse>
    <!-- y轴数值设置 -->
    <el-collapse >
      <el-collapse-item >
         <template slot="title">
          <span class="axiso_title">y轴</span><i class="el-icon-caret-right"></i></template>
        <div v-for="(series,index) in dblclickObj.option.series" :key="index">
         <div class="delect_axisoy" @mouseenter="showDelectIconMet(index)" @mouseleave="closeDelectIco">
            <div class="delect_input">
              <el-input v-model="modifiteItemY[index]" :placeholder="series.data" @change="changeInputY(index)"></el-input>
            </div>
            <!-- 删除 -->
            <div class="delect_icon" v-show="showDelectIcon&&n==index" >
              <el-button size="small" type="danger" icon="el-icon-delete" circle @click="delectAxisoItem(index)"></el-button>
            </div>
         </div>
        </div>
        <!-- 添加 -->
        <div class="add_yaxiso" @click="addInputItemY()"><i class="el-icon-circle-plus-outline"></i></div>
      </el-collapse-item>
    </el-collapse>

    </div>
 </div>
</template>

<script>
import { mapState, } from 'vuex'
 export default {
   components: {

   },
   props: {
     dblclickObj: {
       type: Object,
       default: null,
     },
    

   },
   data () {
     return {
       editCurrentChartobj:{},
      //  图表题目
       titleText:'',
      //  x轴变量对象，数组
       modifiteItemX:'',
       modifiteItemArrX:[],
      //  y轴变量数组
       modifiteItemY:[],
       modifiteItemArrY:[],

       //组件类型
       chartType:'',
       //判断显示产出icon的显示
       showDelectIcon:false,
       n:0,
     }
   },
   watch:{
     dblclickObj:{
       handler(newVal){
        console.log('test.vue==>handler')
         this.modifiteItemY=[]
         this.dblclickObj=newVal
         this.titleText=newVal.option.title.text
         this.modifiteItemX=newVal.option.xAxis.data+''
         newVal.option.series.forEach((element =>{
           this.modifiteItemY.push(element.data+'')
         }))
         this.chartType=newVal.option.series[0].type
        //  this.modifiteItemY=newVal.option.series
         console.log('=====test.vue==>this.dblclickObj==>',this.dblclickObj)
         console.log('=====test.vue==>this.==>currentList',this.currentChartList)
        //  console.log('=====test.vue==>this.editCurrentChartobj==>this.modifiteItemY',this.modifiteItemY)
        
       },
       deep:true,
        immediate: true
     }
   },
   created () {
     console.log('this.dblcledit',this.dblclickObj)
    //  console.log('test.vue==>this.currentChartList==>',this.currentChartList)
   },
   mounted () {
   },
    computed: {
    ...mapState({
       currentChartList: state => state.currentChartList,
     }),
  },
   methods: { 
    //  编辑标题
     changeTitle(id){
       this.$emit("renderEcharts",id)
     },
    //  删除y轴
     delectAxisoItem(index){
       console.log('test.vue==>delectAxisoItem')
       console.log('test.vue==>',index)
       this.dblclickObj.option.series.splice(index,1)
       console.log('test.vue==>this.dblclickObj.option.series',this.dblclickObj.option.series)
       this.$emit("renderEcharts",this.dblclickObj.id)
     },
    //  显示删除icon
     closeDelectIco(){
       this.showDelectIcon=false
     },
     showDelectIconMet(index){
       this.n=index
       this.showDelectIcon=true
     },
    //  x输入框发生变化
     changeInputX(){
       console.log("test==changeInputX")
       this.modifiteItemArrX=this.modifiteItemX.split(',')
       console.log("77777",this.modifiteItemArrX)
       this.currentChartList.forEach(element => {
         if(this.dblclickObj.id==element.id){
           console.log("......,",this.dblclickObj.id)
           element.option.xAxis.data=this.modifiteItemArrX
           console.log("888888888",this.currentChartList)
           this.$emit("renderEcharts",this.dblclickObj.id)
         }
       });
     },
    //  y输入框发生变化
     changeInputY(index){
       console.log("test=666666=>changeInputY",this.modifiteItemY)
      //  this.modifiteItemArrY[index]=this.modifiteItemY[index].split(',')
       console.log("77777",index)
       this.currentChartList.forEach(element => {
        
         if(this.dblclickObj.id==element.id){
           console.log("......,",this.dblclickObj.id)
           element.option.series[index].data=this.modifiteItemY[index].split(',')
           console.log("888888888",element.option.series)
           this.$emit("renderEcharts",this.dblclickObj.id)
         }
       });
     },
    //  添加y轴
     addInputItemY(){
      console.log("test==addInputItemY")
       let item = {
         data:[],
         type:this.chartType
       }
       this.dblclickObj.option.series.push(item)
       this.modifiteItemY.push(item.data+'')      
     },
   },
 }
</script>

<style scoped lang='less'>
  .edit_char_config{
    background: #f7f7fc;
     .title_chart{
      display: flex;
      height: .19rem;
      .title_text{
        width:.38rem;
        text-align:center;
        padding-top: .04rem;
        display:block;
      }
    }
    .coordinate{
      display: flex;
      border: 0.01rem solid #cbeded;
      .A_bscissa{
        display: flex;
        height: .19rem;
         .title_text{
        width:.38rem;
        text-align:center;
        padding-top: .04rem;
        display:block;
        }
        /deep/.el-input {
            width: .38rem;
            margin: auto;
        }
      }
      .O_rdinate{
        display: flex;
        height: .19rem;
        .title_text{
        width:.38rem;
        text-align:center;
        padding-top: .04rem;
        display:block;
        }
        /deep/.el-input {
            width: .38rem;
            margin: auto;
        }
      }

    }
    .axiso_title{
      font-size: 14px;
      padding-left: .13rem;
    }
    .add_yaxiso{
      height: 1px;
      width: 100%;
    }
     .add_yaxiso :hover{
      height: 18px;
      width: 100%;
      background-color: #f7f7fc;
    }
    .delect_axisoy{
      display: flex;
      .delect_input{
        flex: 9;

      }
      .delect_icon{
        flex: 1;
        height: 50%;
        margin: auto;
      }
    }

    /deep/.el-collapse-item__header {
    background-color: #f7f7fc;
}
  }
 

 
</style>
