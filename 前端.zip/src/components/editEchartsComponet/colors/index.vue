<template>
  <div class="block">
    <el-collapse >
     <el-collapse-item >
      <template slot="title">
      <span class="axiso_title">color :</span><i class="el-icon-caret-right"></i></template>
      <div class="color_item">
        <el-input class="color_input" v-model="colorString"></el-input>
        <div class="color_picker">
          <el-color-picker
            v-model="color">
          </el-color-picker>
        </div>
      </div>
     </el-collapse-item >
    </el-collapse>
  </div>
</template>

<script>
import { mapState, } from 'vuex'
export default {
  data(){
    return {
      color:'#409EFF',
      colorString:'',
      colorArr:[],
    }
  },
  props: {
     dblclickObj: {
       type: Object,
       default: null,
     },
   },
   watch:{
     dblclickObj:{
       handler(newVal){
        console.log('color.vue==>handler',newVal)
        //  this.colorArr=[]
         this.dblclickObj=newVal
         this.colorArr=[]
        //  this.colorString=''
         console.log('=====color.vue==>this.dblclickObj==>',this.dblclickObj)
         console.log('=====color.vue==>this.==>currentList',this.currentChartList)
         this.colorArr=newVal.option.color
         this.colorString=this.colorArr+''
        //  if(Object.prototype.hasOwnProperty.call(newVal.option, 'color')){
        //    console.log('=====color.vue==>if')
        //    this.dblclickObj.option.color.forEach((element =>{
        //      console.log('===>color=>if=>element',element)
        //     this.colorArr.push(element)
        //   }))
        //   this.colorString=this.colorArr+''
        //  }else{
        //    this.colorString='#409EFF'
        //  }
       },
       deep:true,
        immediate: true
     },
     color(newVal,oldVal){
       console.log('color==>newVal,oldVal',newVal,oldVal)
        // if(!this.dblclickObj.option.color){
        //   this.colorArr=[]
        //    console.log('=====color==>this.dblclickObj==>',this.dblclickObj)
        //    this.dblclickObj.option.color=[]
        //    this.dblclickObj.option.color.push(newVal)
        //    this.colorArr.push(newVal)  
        //  }else{
        //    this.colorArr=[]
        //    console.log("color==>else",newVal,oldVal)
        //    console.log("color==>else=>this.dblclickObj", this.dblclickObj)
        //    console.log("color==>else=>this.color", this.color)
        //    this.dblclickObj.option.color.push(newVal)
        //    this.dblclickObj.option.color.forEach((element =>{
        //     this.colorArr.push(element)
        //   }))
        //  }
       this.colorArr=[]
       this.dblclickObj.option.color.push(newVal)
        this.dblclickObj.option.color.forEach((element =>{
        this.colorArr.push(element)
        }))
       this.colorString=this.colorArr+''
       this.$emit("renderEcharts",this.dblclickObj.id)
     },
     colorString(newVal,oldVal){
       if(newVal!==oldVal){
         console.log("colorString==>",newVal,oldVal)
        this.colorArr=[]
        this.colorArr=newVal.split(',')
        this.dblclickObj.option.color=this.colorArr
        this.$emit("renderEcharts",this.dblclickObj.id)
       }
       
     }
   },
   created () {
     console.log('this.dblcl',this.dblclickObj)
   },
   computed: {
    ...mapState({
       currentChartList: state => state.currentChartList,
     }),
  },

}
</script>
<style lang="less" scoped>
  .block{
    margin: 0;
    padding: 0;
    border: solid 1px #f7f7fc;
    .axiso_title {
        font-size: 14px;
        padding-left: 0.13rem;
    }
    .demonstration{
      width: 100%;
      height: 100%;
      text-align: center;
    }
    .color_item{
      display: flex;
      .color_input{
        flex: 8;
      }
      .color_picker{
        flex: 2;
      }

    }
  }
   /deep/.el-collapse-item__header {
    background-color: #f7f7fc;
    }
    /deep/.el-collapse-item__content {
    
    padding-bottom: 0;
    margin: auto;
}

</style>