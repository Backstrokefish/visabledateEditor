<template>
    <vue-draggable-resizable
        :w="250"
        :h="250"
        :min-width="250"
        :min-height="250"
        :parent="true"
        :grid="[10,10]"
        class-name="dragging1"
        :style="{left:initDragLeft+ 'px',top:initDragTop + 'px'}"
        @dragging="onDrag"
        @resizing="onResize"
      >
      <slot></slot>
    </vue-draggable-resizable> 

  
</template>

<script>
export default {
  props:{
      dragOffSet:{
       type: Object,
       default: function () {
         return {
           left: 0,
           top: 0,
         }
      }
     }
  },
  data(){
    return{
        initDragLeft:0,
       initDragTop:0,
      width: 0,
      height: 0,
      x: 0,
      y: 0
    }
  },
   created () {
     this.initDragOffSet()
   },
  methods: {
      initDragOffSet(){
        this.initDragLeft=this.dragOffSet.left
        this.initDragTop=this.dragOffSet.top
      },
    onResize(x, y, width, height) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
    },
    onDrag(x, y) {
      this.x = x;
      this.y = y;
    }
  }
  
}
</script>

<style lang="less" scoped>
.dragging1 {
  border: 1px solid #000;
  color: #000;
}
</style>