<template>
  <div class="grid">
    <div class="grid-content" ref="canvas" @drop.prevent="drop($event)" @dragover.prevent=""
      >   
        <vdr 
        :parent="true"
        v-for="(Chart,index) in currentChartList" :key="index"
        @activated="onActivated(Chart)"
        :is-conflict-check="true" 
        :w="currentChartList[index].width"
        :h="currentChartList[index].height"
        :x="currentChartList[index].x"
        :y="currentChartList[index].y"
        :minWidth="250"
        :minHeight="250"
        @resizing="onResizing"
        @dragging="onDragging"
        :snap="true" :snap-tolerance="10"
        @deactivated="onDeactivated(Chart)"
        >
          <i v-show="deleteBool" class="el-icon-delete"  @click="deleteEhart(index)"></i>
          <div class="drag-item-echarts-histogram" ref="dragChart"   :id="Chart.id" :key="index" style="height: 100%;width: 100%;"></div> 
        </vdr>
         
    </div>
      <!-- 辅助线 -->
      <!-- <span class="ref-line v-line"
            v-for="(item,index) in vLine" :key="index+item"
            v-show="item.display"
            :style="{ left: item.position, top: item.origin, height: item.lineLength}"
      />
      <span class="ref-line h-line"
      v-for="(item,index) in hLine" :key="index+item"
      v-show="item.display"
      :style="{ top: item.position, left: item.origin, width: item.lineLength}"
        /> -->
      
    <!-- 编辑组件 -->
    <div class="edit-data" v-if="showEdit&&currentChartList!=''" >
      <line-bar-edit  v-if="showEdit&&currentChartList!=''&&(typeBool=='lineCharts'||typeBool=='barChart')" :dblclickObj='paramChart' @renderEcharts="renderEcharts"></line-bar-edit>
      <pie-chart-edit  v-if="showEdit&&currentChartList!=''&&(typeBool=='pieChart')" :dblclickObj='paramChart' @renderEcharts="renderEcharts"></pie-chart-edit>
      <radar-chart-edit   v-if="showEdit&&currentChartList!=''&&(typeBool=='radarChart')" :dblclickObj='paramChart' @renderEcharts="renderEcharts"></radar-chart-edit>
      <gauge-chart-edit  v-if="showEdit&&currentChartList!=''&&(typeBool=='gaugeChart')" :dblclickObj='paramChart' @renderEcharts="renderEcharts"></gauge-chart-edit>
      <funel-chart-edit  v-if="showEdit&&currentChartList!=''&&(typeBool=='funnelChart')" :dblclickObj='paramChart' @renderEcharts="renderEcharts"></funel-chart-edit>
      <scatter-chart-edit  v-if="showEdit&&currentChartList!=''&&(typeBool=='scatterChart')" :dblclickObj='paramChart' @renderEcharts="renderEcharts"></scatter-chart-edit>
      <color-edit  v-if="showEdit&&currentChartList!=''" :dblclickObj='paramChart' @renderEcharts="renderEcharts" ></color-edit>
      <background-color-edit  v-if="showEdit&&currentChartList!=''" :dblclickObj='paramChart' @renderEcharts="renderEcharts" ></background-color-edit>
    </div>
  </div>
</template>

<script>
import screenfull from 'screenfull'
import vdr from 'vue-draggable-resizable-gorkys'
import 'vue-draggable-resizable-gorkys/dist/VueDraggableResizable.css'
import VueDraggableResizable from 'vue-draggable-resizable'
import 'vue-draggable-resizable/dist/VueDraggableResizable.css'
// import Chart from '../editEchartsComponet/index.vue'
import LineBarEdit from '../editEchartsComponet/linebaredit.vue'
import PieChartEdit from '../editEchartsComponet/piechartedit.vue'
import RadarChartEdit from '../editEchartsComponet/radarchartedit.vue'
import GaugeChartEdit from '../editEchartsComponet/gaugechartedit.vue'
import FunelChartEdit from '../editEchartsComponet/funelchartedit.vue'
import ColorEdit from '../editEchartsComponet/colors/index.vue'
import ScatterChartEdit from '../editEchartsComponet/scatterchartedit.vue'
import BackgroundColorEdit from '../editEchartsComponet/backgroundColor/index'
import Vue from 'vue'
import ChartClass from '@/assets/class/chart.js'
import { mapGetters, mapState, mapMutations } from 'vuex'
import {EleResize} from '@utils/commonUtils'
import  DragResize from '../../components/DragResize.vue'
import bus from '../../utils/bus'

import html2canvas from 'html2canvas'
import {saveChartsList,saveCanvas} from '@api/echarts.js'
    Vue.prototype.closeBeforeSave = () =>{
      window.onbeforeunload = function (e){
        e = e || window.event;
        if(e){
          e.returnValue = '关闭提示'
        }

        return '关闭提示'
      }
    }
    
export default {
    components: { DragResize,LineBarEdit,VueDraggableResizable,vdr,PieChartEdit,
                  RadarChartEdit,GaugeChartEdit,FunelChartEdit,ColorEdit,
                  BackgroundColorEdit,ScatterChartEdit,
                  },
    // components: { Chart},
    data(){
      return {
      key:0,
      n:0,
      left:300,
      top:300,
      width:300,
      height:300,
      x: 0,
      y: 0,
      vLine: [],
      hLine: [],
      showEdit:false,
      chartIndex: 0,
      getIndex:0,
      initdragoffset:{
        left:0,
        top:0,
      },
      //当前编辑的chart
      currentChart:{
        index:0,
        id:0,
        x:0,
        y:0,
        w:300,
        h:300,
        option:{}
      },
      //传给edit编辑的对象
      paramChart:{},
       //当前组件的option
      currentOption:{},

      chart:null,
      b:{},
      deleteBool:false,

      // 组件编辑切换判断
      typeBool:'',
      
      file_url:'',
      closeDialog:false
      }
    },
    props:{
       IsCanvasPrepared: {
        type: Boolean,
        default: false
      },
      isFullSize: {
        type: Boolean,
        default: false
      },
      addChartType: {
      type: Object,
    },
    },
    computed: {
    ...mapState({
       dataVisualization: state => state.dataVisualization,
       echartsListCompt:state => state.echartsListCompt,
       currentChartList:state => state.currentChartList
      //    get(state){
      //      return state.currentChartList
      //    },
      //    set(val){
      //      this.currentChartList=val
      //    }
      //  } 
     }),
     ...mapGetters(['getDataEchartsItem','getDataEchartsIndex',]),
  },
  watch:{
    // 监听全屏操作
    isFullSize () {
      this.handleFullScreen()
    },
    /*
    监听到组件类型，就添加组件配置，赋值给currentChartList
    */
    addChartType:{
      handler(Obj){
        this.typeBool=Obj.type
        this.appendChart(Obj.type)
        console.log('canveContain=>this.addChartType',this.addChartType)
        console.log("canveContain=>this.currentList==>",this.currentChartList)
        this.currentChart.id=this.currentChartList[this.currentChartList.length-1].id
      },
      deep: true
     
    },
    currentChart:{
      handler(newVal,oldVal){
        console.log('canveContain=>currentChart==>newVal',newVal)
        console.log('canveContain=>currentChart==>oldVal',oldVal)
        newVal.x=parseInt(newVal.x)
        newVal.y=parseInt(newVal.y)
        newVal.w=parseInt(newVal.w)
        newVal.h=parseInt(newVal.h)
        if(this.currentChartList.length>0){
          this.currentChartList.forEach((element)=>{
          if(element.id==newVal.id){
            element.x=newVal.x
            element.y=newVal.y
            element.width=newVal.w
            element.height=newVal.h
          }
        })
        }
        this.paramChart=newVal
      },
      deep:true,
      immediate: true
    }
  },
  created(){
     bus.$on('setEchartsListMet',(val)=>{
       this.currentChartList.forEach(el=>{
         this.renderEcharts(el.id)
       })
      
       this.showEdit=JSON.parse(val)
       this.typeBool=this.currentChartList[this.currentChartList.length-1].type
       
        console.log('...this.showEdit',this.showEdit,typeof(this.showEdit))
        console.log('...this.this.typeBool',this.typeBool)
        console.log('...currentChartList',this.currentChartList!='')
        console.log('...currentChartList',this.paramChart)
        // this.changShowEdit()
        
       })
  },
  methods:{
    // changShowEdit(val){
    //   console.log("???????????????????????????")
    //   let Chart = this.currentChartList[this.currentChartList.length-1]
    //   this.currentChart.id=Chart.id
    //   this.currentChart.option=Chart.option
    //   this.currentChart.x=Chart.x
    //   this.currentChart.y=Chart.y
    //   this.currentChart.w=Chart.width
    //   this.currentChart.h=Chart.height
    //   this.deleteBool=true
    //   this.typeBool=Chart.type

    //   this.showEdit=val
    // },
    ...mapMutations(['addDataEchartsItem','addDataEchartsIndex','addChart','setCurEdit','updateChart','setCurrentEchart']),
    setEchartsLisetMeth(val){
      this.setCurrentEchart(val)
      this.currentChartList = val
    },
    saveImage(name) {
      console.log('截图')
      const ImageDiv= this.$refs.canvas;
      //使用html2canvas把界面内容生成图片
      html2canvas(ImageDiv).then(canvas=>{
        this.file_url = canvas.toDataURL("image/png",1.0)
        this.file_url=this.file_url.toString().substring(this.file_url.indexOf(",")+1)
        this.saveCanvasEchart(name)
      })
    },
    saveCanvasEchart(name){
      console.log('this.currentChartList',this.currentChartList)
      let echartlist={
        list:[],
      }
      this.currentChartList.forEach(element => {
        let arr = {
          height:element.height,
          id:element.id,
          type:element.type,
          width:element.width,
          x:element.x,
          y:element.y,
          option:element.option
        }
        echartlist.list.push(arr)
      });
      
      let canvasList = new FormData()
      canvasList.append('fileName',name)
      canvasList.append('fileUrl',this.file_url)
      
      saveCanvas(canvasList).then((res)=>{
        console.log('saveCanvas',res)
        if(res.data.status==1){
            saveChartsList(echartlist).then((res)=>{
              console.log('res',res)
              if(res.data.status==1){
                this.$message({
                  type: 'success',
                  message: res.data.message
                });
               this.$emit('transfer',this.closeDialog)
              
              }else{
                console.log(res.data)
              }
          })
        }else{
          console.log(res.data)
        }
      })
    },



    changeTypeChart(type){
      this.typeBool=type
    },
     // 删除组件
    deleteEhart(index){
      console.log("delectEhart",index)
       this.$confirm('此操作将永久删除该组件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.currentChartList.splice(index,1)
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
    },
    onActivated(Chart){
      console.log('======start',Chart)
      this.currentChart.id=Chart.id
      this.currentChart.option=Chart.option
      this.currentChart.x=Chart.x
      this.currentChart.y=Chart.y
      this.currentChart.w=Chart.width
      this.currentChart.h=Chart.height
      this.deleteBool=true
      this.typeBool=Chart.type
    },
    onDeactivated(Chart){
      console.log('======end',this.currentChart)
      this.currentChartList.forEach(element => {
        if(Chart.id==element.id){
          element.x=this.currentChart.x
          element.y=this.currentChart.y
          element.width=this.currentChart.w
          element.height=this.currentChart.h      
        }
      });
      this.deleteBool=false
    },
    getRefLineParams (params) {
      console.log('param',params)
      const { vLine, hLine } = params
      this.vLine = vLine
      this.hLine = hLine
    },
    onDragging(left,top){
      this.currentChart.x=left
      this.currentChart.y=top
    },
    onResizing(left,top,width,height){
      // console.log(left,top,width,height)
      this.currentChart.x=left
      this.currentChart.y=top
      this.currentChart.w=width
      this.currentChart.h=height
      this.showEdit=true
    },
      
     
    appendChart (type) {
      const config = require(`@/assets/echarts-config/${type}.js`)
      console.log('canveContain=>appendChart=>config',config)
      this.addChart(new ChartClass({
        type:type,
        option: config.option
      }))
    },
      handleFullScreen () {
        if (screenfull.isEnabled) {
          screenfull.request(this.$refs.canvas)
        }
      },
      drop(event){
      const data=this.echartsListCompt
      this.changeTypeChart(this.echartsListCompt)
      console.log('canveContain.vue=>drop==this.echartsListCompt',this.echartsListCompt)
      this.initdragoffset.left=event.offsetX
      this.initdragoffset.top=event.offsetY
      // console.log('canveContain.vue=>drop==event',event)
      // console.log('canveContain.vue==>initdragoffset',this.initdragoffset)
      this.addDataEchartsIndex({type: data});
        let obj = {
          id: this.addChartType.type + this.getDataEchartsIndex({type: this.addChartType.type}),
          option:this.currentChartList[this.currentChartList.length-1].option
        };
        let histogramObj = {
           type: this.addChartType.type,
           option: obj,
        };
        this.currentOption=histogramObj.option.option
        this.currentChart.option=this.currentOption
        this.currentChart.x=this.initdragoffset.left
        this.currentChart.y=this.initdragoffset.top

        this.addDataEchartsItem(histogramObj);
        this.renderEcharts(this.currentChartList[this.currentChartList.length-1].id);

        console.log('canveContain.vue==>dataVisualization.dataEcharts',this.dataVisualization.dataEcharts)
        console.log('canveContain.vue==>dataVisualization.dataEcharts.barChart',this.dataVisualization.dataEcharts.barChart)
        console.log('this.$refs.dragChart.style',this.$refs.dragChart)
        this.showEdit=true
    },

    renderEcharts(id){
      console.log("...........id",id)
      this.$nextTick(() =>{
        console.log("canveContain.vue==>this.currentChartList",this.currentChartList)
        console.log("canveContain.vue==>document.getElementById(this.getIndex)",document.getElementById(id))
        let myChart = this.$echarts.init(document.getElementById(id));
        myChart.setOption((()=>{
            this.currentChartList.forEach((element)=>{
              if(element.id==id){
                console.log("setOption")
                this.b=element
              }
            })
            // let b = this.currentChartList[this.getIndex];
            console.log("canveContain.vue==>this.currentChartList[this.getIndex]",this.b )
            this.b.myChart = myChart;
            return this.b.option;
        })(),true);
        this.getIndex++
        //定义图表重置监听函数
        let listener = function () {
              myChart.resize()
        };
        EleResize.on(document.getElementById(id), listener)
        // document.getElementById(id).setAttribute('_echarts_instance_', '')
      });
    },
   changeSelectItem(item,type){
      this.dblclickObj = item;
      this.dblclickType = type;
    },
     handlechange(index){
      this.getIndex=index;
    },
    getmouseEvenMet(e){
      console.log('lalallalalalla',e)
    },
    // changeOffset(t){
    //   console.log('2')
    //   this.$nextTick(()=>{
    //   const currentChart = { ...this.currentChart }
    //   currentChart.x=t.disX
    //   currentChart.y=t.disY
    //   currentChart.w=t.disW
    //   currentChart.h=t.disH
    //   currentChart.option=this.currentOption
    //   this.currentChart = currentChart
    //   this.showEdit=true
    //   })
    //   console.log('this.currentChart==>',this.currentChart)

    // },
      onResize (x, y, width, height) {
      this.updateChart({
        index: this.chartIndex,
        x,
        y,
        height,
        width
      })
    },

    /**
     * @description 响应图表拖拽
     * @params {Array} 图形左上角(x,y)坐标
     */
    onDrag (x, y) {
      this.updateChart({
        index: this.chartIndex,
        x,
        y
      })
    },

     onClickChart (item, index) {
      this.setCurEdit(item)
      this.chartIndex = index
     
    },
  },
  mounted(){
    this.closeBeforeSave()
  }
}
</script>

<style lang="less" scoped>
.grid{
  margin: 0;
  padding: 0;
  display: flex;
  width: 100%;
  height: 100%;

  .grid-content{
  flex: 8;
  position: relative;;
  border: steelblue .01rem solid;
  background-color: aliceblue;
  width: 100%;
  height: 100%;
    .drag-item-echarts{
        // position: absolute;
        border: .01rem solid rgb(94, 104, 161);
        height: 1.25rem;
        width: 1.88rem;
    .drag-item-echarts-histogram{
        height: 100%;
        width: 100%;
        margin: auto auto;
        padding: 0;
      }

    }
 
  }

.edit-data{
  flex: 2;
  height: 100%;
  width: 100%;
  border: antiquewhite .01rem solid;
}

}



</style>