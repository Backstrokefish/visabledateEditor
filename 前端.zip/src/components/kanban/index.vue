<template>
  <div class="kanban_style">
    <div v-for="(item,index) in echartList " :key="index+item._id" class="canvas_style"
      :id="item._id" :style="{height:item.height+'px',width:item.width+'px',left:item.x+'px',top:item.y+'px'}" 
    >
      
      <!-- <div :id="item._id" :style="{height:item.height+'px',width:item.width+'px',left:item.x+'px',top:item.y+'px'}" ></div> -->
    </div>
  </div>
</template>

<script>

import {getEchartsList} from '@api/echarts.js'
import bus from '../../utils/bus'
export default {
  data(){
    return{
      echartList :[],
      canvasId : {
        id:0,
      },
    }
  },
  computed:{
    // getcanvasId(){
    //   console.log('computed')
    //   return bus.data.id
    // }
  },
  created(){

      console.log("bus.data.id",bus.data.id)
      this.getEchartsListMet(bus.data.id)
     
  },
  mounted(){
  
   setTimeout(() => {
     this.initEchart()
   }, 1000);

  },
  methods:{
    getEchartsListMet(val){
      console.log('getEchartsListMet')
      this.canvasId.id = val
      getEchartsList(this.canvasId).then((res)=>{
        console.log('res',res)
        this.echartList=res.data.data
        console.log('this.echartList',this.echartList)
      })
    },
    initEchart(){
      console.log('inite')
      this.echartList.forEach(el=>{
         console.log('inite',document.getElementById(el._id))
        const myChart = this.$echarts.init(document.getElementById(el._id))
        myChart.setOption(el.option)
      })
    }
  },

}
</script>

<style lang='less' scoped>

  .kanban_style{
    position: relative;
    display: flex;
    .canvas_style{
      position: absolute;
    }
  }

</style>