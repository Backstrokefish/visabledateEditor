<template>
    <div class="drag-resize-component" id="drag" ref="drag" @click="showResizeTag" :style="{left:initDragLeft+ 'px',
    top:initDragTop + 'px',
  
    background:avtivecolor}"  
   @mouseleave='Mouseleave'
   @mouseenter='Mouseover'

   >
    <div v-show="isResize && resizeFlag" ref="resizeDivTag" id="resizeDivTag" class="drag-guid">
        <span class="br"></span>
        <span class="bl"></span>
        <span class="tr"></span>
        <span class="tl"></span>
         <div class="guide-leftTop"></div>
          <div class="guide-rightTop"></div>
          <div class="guide-leftBottom"></div>
          <div class="guide-rightBottom"></div>   
    </div>
     
    <slot></slot>
    </div>

</template>

<script>
// import { mapMutations,mapGetters } from 'vuex'
 export default {

   props:{
    //  resizeFlag:{
    //    type: Boolean,
    //    default: false,
    //  },
     isDrag: {  // 是否可拖拽，默认true
       type: Boolean,
       default: true,
     },
     isResize: { // 是否可缩放，默认为false
       type: Boolean,
       default: false,
     },
     dragOffSet:{
       type: Object,
       default: function () {
         return {
           left: 0,
           top: 0,
         }
      }
     }
   },
   watch:{
      offsetConfig:{
      handler(newval){
        console.log('offsetConfig>>>>>>>>>==>t',newval)
        this.$emit('changeOffset',newval)
        this.$emit('change')
        // this.getOffset()
      },
      deep:true
      
     }
   },
    computed: {
  },
   data () {
     return {
       resizeFlag: false, // 可拖动的标志位
       initDragLeft:0,
       initDragTop:0,
       avtivecolor: "#f7f7fc",
       chartType:'',
       offsetConfig:{
         disX:0,
         disY:0,
         disW:0,
         disH:0,
       },
       paramOffsetConfig:{
         x:0,
         y:0
       }
     }
   },
   created () {
     this.initDragOffSet()
   },
   mounted () {
     if(this.isDrag){
        this.initDrag();
        this.getOffset()
     }
     if(this.isResize){
        this.initResize();
     }
   },
   methods: { 
     getOffset(){
       let arrleft = this.$refs.drag.style.left.split('px')
       let arrTop = this.$refs.drag.style.top.split('px')
       console.log('this.$refs.drag.style.width==>',this.$refs.drag.style)
      //  let arrWidth = this.$refs.drag.style.width.split('px')
      //  let arrheight = this.$refs.drag.style.height.split('px')
      //  console.log('ref',arr)
       this.offsetConfig.disX=parseInt(arrleft[0])
       this.offsetConfig.disY=parseInt(arrTop[0])
      //  this.offsetConfig.disW=parseInt(arrWidth[0])
      //  this.offsetConfig.disH=parseInt(arrheight[0])
        console.log('this.offsetConfig',this.offsetConfig)
     },
    getStyleWHset(){
       let arrWidth = this.$refs.drag.style.width.split('px')
       let arrheight = this.$refs.drag.style.height.split('px')
       this.offsetConfig.disW=parseInt(arrWidth[0])
       this.offsetConfig.disH=parseInt(arrheight[0])
    },
      Mouseover(){
        this.avtivecolor="#3a8ee6"
      },
      Mouseleave(){
        this.avtivecolor="#f7f7fc"
      },

      initDragOffSet(){
        this.initDragLeft=this.dragOffSet.left
        this.initDragTop=this.dragOffSet.top
      },
      showResizeTag(){
        this.resizeFlag = !this.resizeFlag;
      },
      // 初始化可缩放
      initResize(){
        let el = this.$el;
        // console.log('el',el)
        let spanNodes = this.$refs.resizeDivTag.childNodes;
        // console.log('spanNodes',spanNodes)
        for(let i=0;i<spanNodes.length;i++){
          this.resizeElementFun(spanNodes[i],el);
        }
      },
      resizeElementFun(element,el){
        element.onmousedown = function(ev){
          console.log('我是按下的元素')
          let oEv = ev || event;
          oEv.stopPropagation();
          let oldWidth = el.offsetWidth;
          let oldHeight  = el.offsetHeight;
          console.log('-----'+ oldWidth+'----'+oldHeight);
          let oldX = oEv.clientX;
          let oldY = oEv.clientY;
          let oldLeft = el.offsetLeft;
          let oldTop = el.offsetTop;
          console.log('--zuo---'+ oldLeft+'--gao--'+oldTop);
          document.onmousemove = function(ev){
            // oEv.stopPropagation();
            let oEv = ev || event;
            let disY = (oldTop + (oEv.clientY - oldY));
            // let disX = (oldLeft + (oEv.clientX - oldLeft));
            let disX = (oldLeft + (oEv.clientX - oldX));
            if(disX>oldLeft+oldWidth){
                disX=oldLeft+oldWidth
            }
            if(disY>oldTop+oldHeight){
                disY=oldTop+oldHeight
            }
            if(element.className == 'tl'){
              el.style.width = oldWidth - (oEv.clientX - oldX) + 'px';
              el.style.height = oldHeight - (oEv.clientY - oldY) + 'px';
              el.style.left = disX + 'px';
              el.style.top = disY + 'px';
            } else if (element.className == 'bl'){
              el.style.width = oldWidth - (oEv.clientX - oldX) + 'px';
              el.style.height = oldHeight + (oEv.clientY - oldY) + 'px';
              el.style.left = disX + 'px';
              // el.style.bottom = oldTop + (oEv.clientY + oldY) + 'px';
            } else if (element.className == 'tr'){
              el.style.width = oldWidth + (oEv.clientX - oldX) + 'px';
              el.style.height = oldHeight - (oEv.clientY - oldY) + 'px';
              el.style.right = oldLeft - (oEv.clientX - oldX) + 'px';
              el.style.top = disY + 'px';
            } else if (element.className == 'br'){
              el.style.width = oldWidth + (oEv.clientX - oldX) + 'px';
              el.style.height = oldHeight + (oEv.clientY - oldY) + 'px';
              el.style.right = oldLeft - (oEv.clientX - oldX) + 'px';
              // el.style.bottom = oldTop + (oEv.clientY + oldY) + 'px';
            }
          }
          document.onmouseup = function(){
            document.onmousemove = null;
          };
          el.onmouseup= ()=>{
              this.getStyleWHset()
          }
          return false;
        }
      },
      // 初始化可拖拽方法
      initDrag(){
       let el = this.$el;
       console.log('初始化可拖拽方法')
       el.onmousedown = (e)=>{
            let elParentW = e.path[4].offsetWidth
            let elParentH = e.path[4].offsetHeight 
            // console.log('elParent',elParentW)
            e.preventDefault();
            e.target.style.cursor = 'move'; 
         //鼠标按下，计算鼠标触点距离元素左侧和顶部的距离
            let disX = e.clientX - el.offsetLeft;
            let disY = e.clientY - el.offsetTop;
            // console.log('22222',document);
            document.onmousemove = function (e) {
              //计算需要移动的距离
              let tX = e.clientX - disX;
              let tY = e.clientY - disY;
              // console.log("在移动")
              // console.log('e',e)
              //移动当前元素
              if (tX >= 0 && tX <= elParentW - el.offsetWidth) {
                // console.log('...tX',tX)
                el.style.left = tX + 'px';
                
              } 
              if (tY >= 0 && tY <= elParentH - el.offsetHeight) {
                el.style.top = tY + 'px';
                
              } 
             
              // addDateEchartsOffset
            };
            //鼠标松开时，注销鼠标事件，停止元素拖拽。
            document.onmouseup = function (e) {
                document.onmousemove = null;
                document.onmouseup = null;
                e.target.style.cursor = 'default';
            };
       }
       el.onmouseup= ()=>{
         this.getOffset()
       }
     },
   },
 }
</script>

<style lang='less' scoped>
  .drag-resize-component {
   position: absolute;
   width: 100%;
   height: 100%;
    // 四角
    .tl,.bl,.br,.tr {
      width: 10px;
      height: 10px;
      position: absolute;
      background: #fff;
      border:1px dashed  #2ab1e8;
      z-index: 2;
      cursor: nwse-resize
    }
    .tl,.bl{
       left: -6px;
    }
    .tr,.br{
       right:-6px;
    }
    .br,.bl{
       bottom: -6px;
    }
    .tl,.tr{
       top: -6px;
    }
    .tr,.bl{
      cursor: nesw-resize;
    }

    .dragging1 {
   position: absolute;
   width: 100%;
   height: 100%;
  border: 1px solid #000;
  color: #000;
  }
  .guide-leftTop {
      position: absolute;
      height: 1.25rem;
      width: 1.25rem;
      left:-1.25rem;
      top: -1.25rem;
      border: 1px dashed #2ab1e8;
      border-top: none;
      border-left: none;
  }
  .guide-rightTop {
      position: absolute;
      height: 1.25rem;
      width: 1.25rem;
      right: -1.25rem;
      top: -1.25rem;
      border: 1px dashed #2ab1e8;
      border-top: none;
      border-right: none;
  }
  .guide-leftBottom {
      position: absolute;
      height: 1.25rem;
      width: 1.25rem;
      left: -1.25rem;
      bottom: -1.25rem;
      border: 1px dashed #2ab1e8;
      border-bottom: none;
      border-left: none;
  }
  .guide-rightBottom {
      position: absolute;
      height: 1.25rem;
      width: 1.25rem;
      right: -1.25rem;
      bottom: -1.25rem;
      border: 1px dashed #2ab1e8;
      border-right: none;
      border-bottom: none;

  }
}

</style>
