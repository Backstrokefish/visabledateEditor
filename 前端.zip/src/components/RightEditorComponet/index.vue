<template>
  <div>
    <edit-size-and-position></edit-size-and-position>
  </div>
</template>

<script>
import editSizeAndPosition from './editSizeAndPosition.vue'
export default {
  components:{
    editSizeAndPosition
  }
}
</script>

<style>

</style>