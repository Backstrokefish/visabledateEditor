<template>
   <div class="editSizePositionConfg">
     <div class="tag">尺寸和位置</div>
      <div class="set-config">
        <div class="set-size">
        <span class="font-set">X:</span><el-input v-model="x" size="small"></el-input>
        </div>
        <div class="set-size">
         <span class="font-set">Y:</span><el-input v-model="x" size="small"></el-input>
        </div>
      </div>
       <div class="set-config">
        <div class="set-size">
         <span class="font-set">W:</span><el-input v-model="x" size="small"></el-input>
        </div>
        <div class="set-size">
         <span class="font-set">H:</span><el-input v-model="x" size="small"></el-input>
        </div>
      </div>

   </div>

</template>

<script>
export default {
  data(){
    return{
      x:1,
    }
  }
}
</script>

<style lang='less' scoped>
  *{
      margin: 0;
      padding: 0;
    }
  .editSizePositionConfg{
    width: 100%;
    height: 100%;
    .tag{
      width: 100%;
      font-size: .1rem;
      text-align: left;
      color: #6c7676;
    }
    .set-config{
      display: flex;
      width: 100%;
      // flex-wrap:wrap;
      .set-size{
        width: 45%;
        border: aqua .01rem solid;
        padding: .06rem;
        .font-set{
          font-size: 0.1rem;
          color: #79827f;
          margin-right: 8px;
        }
        /deep/ .el-input {
        width: 50%;
      }
      }

      
    }
    
  }

</style>