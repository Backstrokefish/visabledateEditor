import server from './axios.js'

export const saveChartsList = (data)=>{
  return server({
    url:'/echart/saveEchart',
    method:'post',
    headers:{'Content-Type':'application/json'},
    data : data
  })
}

export const saveCanvas = (data)=>{
  return server({
    url:'/echart/saveCanvas',
    method:'post',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    data : data
  })
}

export const getCanvas = () =>{
  return server({
    url:'/echart/getCanvas',
    method:'get',
  })
}

export const getEchartsList = (id) =>{
  return server({
    url:'/echart/getEchart',
    method:'post',
    data: id
  })
}

export const delectCanvas = (id) =>{
  return server({
    url:'/echart/delectCanvas',
    method:'post',
    data: id
  })
}