import Vue from 'vue';
export default new Vue(
  {
    data(){
      return {
        data:{}
      }
    },
    created(){
      this.$on('getEchartsListMet',(val)=>{
        console.log('val',val)
        this.data.id = val
      })

   
     
    }
  }
);

